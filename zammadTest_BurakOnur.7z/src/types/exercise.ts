export interface ShowExercises {
  second: boolean
  third: boolean
}
