import type {Config} from '@jest/types';

// Sync object
const config: Config.InitialOptions = {
  verbose: true,
  maxWorkers: '',
  rootDir: ''
};


export default config;
